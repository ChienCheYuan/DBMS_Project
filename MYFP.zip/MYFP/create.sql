CREATE TABLE student (
    student_id VARCHAR PRIMARY KEY,
    student_name VARCHAR,
    student_grade INTEGER,
    major VARCHAR,
    double_major VARCHAR,
    minor_one VARCHAR,
    minor_two VARCHAR,
    gender VARCHAR,
    credit INTEGER,
    student_password VARCHAR
);

CREATE TABLE classroom (
    classroom_id VARCHAR PRIMARY KEY,
    ac VARCHAR,
	projector VARCHAR
);

CREATE TABLE teacher (
    teacher_id VARCHAR PRIMARY KEY,
    teacher_name VARCHAR,
    teacher_email VARCHAR,
    gender VARCHAR,
    teacher_office VARCHAR
);

CREATE TABLE course (
    course_id VARCHAR NOT NULL,
    course_year INTEGER NOT NULL,
    course_semester INTEGER NOT NULL,
	course_credit INTEGER NOT NULL,
    course_name VARCHAR,
	teacher_id VARCHAR, -- REFERENCES teacher (teacher_id)
	course_unit VARCHAR,
    course_time VARCHAR,
	classroom_id VARCHAR, -- REFERENCES classroom (classroom_id)
    type_of_credit VARCHAR,
	change VARCHAR,
    comment VARCHAR,
    CONSTRAINT pk_course_id PRIMARY KEY (course_id,course_year,course_semester)
);

CREATE TABLE opinion (
    option_id VARCHAR PRIMARY KEY,
    course_id VARCHAR NOT NULL, -- REFERENCES course(course_id)
    course_year INTEGER NOT NULL, -- REFERENCES course(course_year)
    course_semester INTEGER NOT NULL, -- REFERENCES course(course_semester)
    content VARCHAR,
    score INTEGER
);
CREATE TABLE tracklist
(
    student_id VARCHAR, -- REFERENCES student(student_id)
    course_id VARCHAR NOT NULL, -- REFERENCES course(course_id)
    course_year INTEGER NOT NULL, -- REFERENCES course(course_year)
    course_semester INTEGER NOT NULL, -- REFERENCES course(course_semester)
    my_back_up VARCHAR,
    CONSTRAINT pk_tracklist PRIMARY KEY (student_id, course_id, course_year, course_semester)
);

CREATE INDEX ix_course_name ON course (course_name);
CREATE INDEX ix_course_time ON course (course_time);
CREATE INDEX ix_course_teacher_id ON course (teacher_id);
CREATE INDEX ix_student_name ON student (student_name);
CREATE INDEX ix_teacher_teacher_id ON teacher (teacher_id);
CREATE INDEX ix_teacher_name ON teacher (teacher_name);
CREATE INDEX ix_tracklist_student on trackList (student_id);