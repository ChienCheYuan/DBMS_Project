from flask import Flask, jsonify, render_template, request, redirect, flash, url_for
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
import os
import psycopg2
app = Flask(__name__)
app.secret_key = os.urandom(16).hex()

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.session_protection = "strong"
login_manager.login_view = 'login'
login_manager.login_message = 'Please Login First'

users = {}
conn = psycopg2.connect(database="FP", user="postgres", password="liou314159265", host="127.0.0.1", port="5432")
cur = conn.cursor()
cur.execute("SELECT *  from student")
rows = cur.fetchall()
for i in rows:
    users[i[0]]={'password':i[9]}
conn.commit()
conn.close()

class User(UserMixin):
    pass

@login_manager.user_loader
def user_loader(u):
    #print("UserLoader")
    if u not in users:
        return

    user = User()
    user.id = u
    return user

@login_manager.request_loader
def request_loader(request):
    #print("RequestLoader")
    u = request.form.get('login_account')
    if u not in users:
        return

    user = User()
    user.id = u

    # DO NOT ever store passwords in plaintext and always compare password
    # hashes using constant-time comparison!
    user.is_authenticated = request.form['login_password'] == users[u]['password']

    return user


@app.route('/')
def hello():    
    return render_template('index.html')


@app.route('/update',methods=['POST'])
@login_required
def update():
    sid = request.form.get('currentStudentId')
    cid = request.form.get('currentCourseId')
    cy = request.form.get('currentCourseYear')
    cs = request.form.get('currentCourseSemester')
    newMessage=request.form.get('updateMessage')
    sql = "update trackList set my_back_up = '{five}' where student_id = '{one}' and course_id = '{two}' and course_year = {three} and course_semester = {four} ".format(five=newMessage,one=sid,two=cid,three=cy,four=cs)
    conn = psycopg2.connect(database="FP", user="postgres", password="liou314159265", host="127.0.0.1", port="5432")
    cur = conn.cursor()   
    cur.execute(sql)
    conn.commit()
    conn.close()
    return redirect(url_for('list'))

@app.route('/delete',methods=['POST'])
@login_required
def delete():
    sid = request.form.get('currentStudentId')
    cid = request.form.get('currentCourseId')
    cy = request.form.get('currentCourseYear')
    cs = request.form.get('currentCourseSemester')
    sql = "delete from trackList where student_id = '{one}' and course_id = '{two}' and course_year = {three} and course_semester = {four} ".format(one=sid,two=cid,three=cy,four=cs)
    conn = psycopg2.connect(database="FP", user="postgres", password="liou314159265", host="127.0.0.1", port="5432")
    cur = conn.cursor()   
    cur.execute(sql)
    conn.commit()
    conn.close()
    return redirect(url_for('list'))

@app.route('/insert',methods=['POST'])
@login_required
def insert():
    sql = "insert into trackList (student_id,course_id,course_year,course_semester,my_back_up) values ('{sid}', '{cid}',{cy},{cs},'')".format(sid = current_user.id,cid = request.form['current_course'],cy=request.form['current_year'],cs=request.form['current_semester']) 
    conn = psycopg2.connect(database="FP", user="postgres", password="liou314159265", host="127.0.0.1", port="5432")
    cur = conn.cursor()   
    cur.execute("select * from trackList where student_id = '{sid}' and course_id = '{cid}' and course_year = {cy} and course_semester = {cs}".format(sid=current_user.id,cid = request.form['current_course'],cy=request.form['current_year'],cs=request.form['current_semester']))
    rows = cur.fetchall()
    if len(rows)==0:
        cur.execute(sql)
    conn.commit()
    conn.close()
    return redirect(url_for('index'))

@app.route('/index.html',methods=['GET','POST'])
def index():
    if  request.method=='GET':
        conn = psycopg2.connect(database="FP", user="postgres", password="liou314159265", host="127.0.0.1", port="5432")
        cur = conn.cursor()
        sql = "select course.course_year,course.course_semester,course.course_id,course.course_name,teacher.teacher_name,course.course_time,course.course_credit,course.course_unit,course.comment from course,teacher where course.teacher_id=teacher.teacher_id"
        #print(sql)
        cur.execute(sql)
        rows = cur.fetchall()
        conn.commit()
        conn.close()
        key = 1
        ccc = []
        for i in rows:
            tmp = []
            tmp.append(key)
            tmp.append(i)
            cid = i[2][0:6]
            tmp.append(cid)
            ccc.append(tmp)
            key = key+1
        return render_template('index.html',searches = ccc)
    else:
        #print(request.form)
        #print(request.form.get('semester_one'))
        tmp=""
        if request.form.get('semester_one') != None:
            tmp = tmp+"course.course_semester = 1 and "
        if request.form.get('semester_two') != None:
            tmp = tmp+"course.course_semester = 2 and "
        tmp = tmp + "(course.course_id like '%{test}%' or course.course_name like '%{test}%' or teacher.teacher_name like '%{test}%') and ".format(test=request.form.get('keySearch'))
        temp = ""
        if request.form.get('monday') != None:
            temp = temp+"course.course_time like '%一%' or "       
        if request.form.get('tuesday') != None:
            temp = temp+"course.course_time like '%二%' or "   
        if request.form.get('wednesday') != None:
            temp = temp+"course.course_time like '%三%' or "   
        if request.form.get('thursday') != None:
            temp = temp+"course.course_time like '%四%' or "   
        if request.form.get('friday') != None:
            temp = temp+"course.course_time like '%五%' or "   
        if request.form.get('saturday') != None:
            temp = temp+"course.course_time like '%六%' or "   
        if request.form.get('sunday') != None:
            temp = temp+"course.course_time like '%日%' or "
        if temp != "":
            tmp = tmp + "(" + temp[0:-3] + ") and "
        if request.form.get('time1') != None:
            tmp = tmp + "course.course_time similar to '%(A|B|1|2)%' and "
        if request.form.get('time2') != None:
            tmp = tmp + "course.course_time similar to '%(3|4|C|D)%' and "
        if request.form.get('time3') != None:
            tmp = tmp + "course.course_time similar to '%(5|6|7|8)%' and "
        if request.form.get('time4') != None:
            tmp = tmp + "course.course_time similar to '%(E|F|G|H)%' and "
        tmp = tmp + "course.course_year = {yyy} and ".format(yyy=request.form.get('which_year'))
        conn = psycopg2.connect(database="FP", user="postgres", password="liou314159265", host="127.0.0.1", port="5432")
        cur = conn.cursor()
        sql = "select course.course_year,course.course_semester,course.course_id,course.course_name,teacher.teacher_name,course.course_time,course.course_credit,course.course_unit,course.comment from course,teacher where {addTmp} course.teacher_id=teacher.teacher_id".format(addTmp=tmp)
        print(sql)
        cur.execute(sql)
        rows = cur.fetchall()
        conn.commit()
        conn.close()
        key = 1
        ccc = []
        for i in rows:
            tmp = []
            tmp.append(key)
            tmp.append(i)
            cid = i[2][0:6]
            tmp.append(cid)
            ccc.append(tmp)
            key = key+1
        return render_template('index.html',searches = ccc)

@app.route('/course_opinion.html',methods=['GET', 'POST'])
def course_opinion():
    if request.method=='POST':
        key = request.form['key']
        conn = psycopg2.connect(database="FP", user="postgres", password="liou314159265", host="127.0.0.1", port="5432")
        cur = conn.cursor()
        cur.execute("SELECT course_id,course_name,teacher_name from course,teacher where course.teacher_id = teacher.teacher_id and course_id = '%s' "%(key))
        rows = cur.fetchall()
        conn.commit()
        conn.close()
        conn = psycopg2.connect(database="FP", user="postgres", password="liou314159265", host="127.0.0.1", port="5432")
        cur = conn.cursor()
        sql = "select course.course_year,course.course_semester,course.course_name,content from opinion,course,teacher where opinion.course_id=course.course_id and course.teacher_id = teacher.teacher_id and teacher.teacher_name like '%{test}%' and course.course_name like '%{n}%'".format(test=rows[0][2],n=rows[0][1])
        #print(sql)
        cur.execute(sql)
        sameCourse = cur.fetchall()
        conn.commit()
        conn.close()
        key = 1
        sc = []
        for i in sameCourse:
            tmp = []
            tmp.append(key)
            tmp.append(i)
            sc.append(tmp)
            key = key+1
        conn = psycopg2.connect(database="FP", user="postgres", password="liou314159265", host="127.0.0.1", port="5432")
        cur = conn.cursor()
        sql = "select course.course_year,course.course_semester,course.course_name,content from opinion,course,teacher where opinion.course_id=course.course_id and course.teacher_id = teacher.teacher_id and teacher.teacher_name like '%{test}%' and course.course_name not like '%{n}%'".format(test=rows[0][2],n=rows[0][1])
        #print(sql)
        cur.execute(sql)
        differentCourse = cur.fetchall()
        conn.commit()
        conn.close
        key = 1
        dc = []
        for i in differentCourse:
            tmp = []
            tmp.append(key)
            tmp.append(i)
            dc.append(tmp)
            key = key+1
    return render_template('course_opinion.html',pc=rows[0],sameCourse=sc,differentCourse=dc)

@app.route('/course_evaluation.html',methods=['GET','POST'])
def course_evaluation():
    if request.method == 'GET':   
        conn = psycopg2.connect(database="FP", user="postgres", password="liou314159265", host="127.0.0.1", port="5432")
        cur = conn.cursor()
        cur.execute("SELECT course_id,course_year,course_semester,course_name,teacher_name,course_time,classroom_id,course_credit  from course,teacher where course.teacher_id = teacher.teacher_id")
        rows = cur.fetchall()
        conn.commit()
        conn.close()
        key = 1
        ccc = []
        for i in rows:
            tmp = []
            tmp.append(key)
            tmp.append(i)
            cid = i[0][0:6]
            tmp.append(cid)
            ccc.append(tmp)
            key = key+1
        return render_template('course_evaluation.html',courses = ccc)
    else:
        keyWord = request.form['keyWord']
        #print(keyWord)
        conn = psycopg2.connect(database="FP", user="postgres", password="liou314159265", host="127.0.0.1", port="5432")
        cur = conn.cursor()
        sql = "SELECT course_id,course_year,course_semester,course_name,teacher_name,course_time,classroom_id,course_credit  from course,teacher where course.teacher_id = teacher.teacher_id and (course_name like '%{test}%' or course_id like '%{test}%' or teacher_name like '%{test}%') order by course_id ".format(test=keyWord)
        #print(sql)
        cur.execute(sql)
        rows = cur.fetchall()
        conn.commit()
        conn.close
        #print(len(rows))
        key = 1
        ccc = []
        for i in rows:
            tmp = []
            tmp.append(key)
            tmp.append(i)
            cid = i[0][0:6]
            tmp.append(cid)
            ccc.append(tmp)
            key = key+1
        return render_template('course_evaluation.html',courses = ccc)

@app.route('/list.html')
@login_required
def list():
    conn = psycopg2.connect(database="FP", user="postgres", password="liou314159265", host="127.0.0.1", port="5432")
    cur = conn.cursor()
    sql = "SELECT *  from student where student_id ='%s'"%(current_user.id)
    cur.execute(sql)
    rows = cur.fetchall()
    conn.commit()
    conn.close()
    for cs in rows:
        uid = cs[0]
        ugrade = cs[2]
        uname = cs[1]
        ucredit = cs[8]
    conn = psycopg2.connect(database="FP", user="postgres", password="liou314159265", host="127.0.0.1", port="5432")
    cur = conn.cursor()
    sql = "SELECT course.course_id,course.course_name,teacher.teacher_name,course.course_time,course.classroom_id,course.course_credit,trackList.my_back_up,course.course_year,course.course_semester  from student,course,teacher,trackList where student.student_id ='{uiid}' and teacher.teacher_id = course.teacher_id and trackList.student_id=student.student_id and course.course_id=trackList.course_id and course.course_year=trackList.course_year and course.course_semester=trackList.course_semester".format(uiid = current_user.id)
    cur.execute(sql)
    rows = cur.fetchall()
    conn.commit()
    conn.close()
    key = 1
    ccc = []
    for i in rows:
        tmp = []
        tmp.append(key)
        tmp.append(i)
        cid = i[0][0:6]
        tmp.append(cid)        
        ccc.append(tmp)
        key = key+1
    return render_template('list.html',user_id = uid,user_name=uname,user_grade=ugrade,user_credit=ucredit,trackList=ccc)

@app.route('/timetable.html')
@login_required
def timetable():    
    return render_template('timetable.html')

@app.route('/check.html')
@login_required
def check():    
    print("check")
    return render_template('check.html')

@app.route('/login.html', methods=['GET', 'POST'])
def login():
    #print("login")
    if request.method == 'GET':
        return render_template("login.html")
    
    u = request.form['login_account'] 
    if (u in users) and (request.form['login_password'] == users[u]['password']):
        #print("1")
        user = User()
        user.id = u
        login_user(user)
        flash('登入成功了...')
        return redirect(url_for('index'))

    flash('登入失敗了...')
    return render_template('login.html')

if __name__=='__main__':
    app.run(debug=True)
